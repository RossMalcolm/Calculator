package cp213;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * 
 * @author rossmalcolm
 * Initialize Calculator
 */
public class Calculator extends JFrame{
	 // Set Panels and Text Areas
	 final JPanel input = new JPanel();
	 final TextArea equation = new TextArea();
	 final JPanel output = new JPanel();
	 final TextArea answer = new TextArea();
	 final JPanel buttons = new JPanel(new GridLayout(4,5));
	 // Set Buttons
	 final JButton b1 = new JButton("1");
	 final JButton b2 = new JButton("2");
	 final JButton b3 = new JButton("3");
	 final JButton b4 = new JButton("4");
	 final JButton b5 = new JButton("5");
	 final JButton b6 = new JButton("6");
	 final JButton b7 = new JButton("7");
	 final JButton b8 = new JButton("8");
	 final JButton b9 = new JButton("9");
	 final JButton b0 = new JButton("0");
	 final JButton bp = new JButton("+");
	 final JButton bs = new JButton("-");
	 final JButton bm = new JButton("*");
	 final JButton bd = new JButton("/");
	 final JButton bc = new JButton("C");
	 final JButton be = new JButton("=");
	 //Set operator booleans
	 private boolean plus = false;
	 private boolean subtract = false;
	 private boolean multiply = false;
	 private boolean divide = false;
	 
	 /**
	  * Create a calculator
	  * @param args
	  */
	 public static void main(String[] args) {
		 //make new calculator
		 new Calculator();
	 }

	 /**
	  * Create the calculator
	  */
	 public Calculator() {
		 //Set Sizes and add textboxes to panels 
		 super();
		 JFrame window = new JFrame("Calculator");
		 input.setPreferredSize(new Dimension(400,150));
		 input.add(equation);
		 output.setPreferredSize(new Dimension(400,150));
		 output.add(answer);
		 buttons.setPreferredSize(new Dimension(400,300));
		 
		 window.setSize(600, 800);
		 //Add all the buttons to the panel in order
		 buttons.add(b7);
		 buttons.add(b8);
		 buttons.add(b9);
		 buttons.add(bd);
		 buttons.add(bc);
		 
		 buttons.add(b4);
		 buttons.add(b5);
		 buttons.add(b6);
		 buttons.add(bm);	 
		 buttons.add(new JButton());
		 
		 buttons.add(b1);
		 buttons.add(b2);
		 buttons.add(b3);
		 buttons.add(bs);
		 buttons.add(new JButton());	
		 
		 buttons.add(new JButton());
		 buttons.add(b0);
		 buttons.add(new JButton());
		 buttons.add(bp);
		 buttons.add(be);
		 
		 //add all three panels to the Frame
		 window.add(input,BorderLayout.PAGE_START);
		 window.add(output, BorderLayout.CENTER);
		 window.add(buttons, BorderLayout.PAGE_END);
		 
		 //set visible and exit on close
		 window.setVisible(true);
		 setDefaultCloseOperation(EXIT_ON_CLOSE);
		 
		 //Add action Listeners
		 b1.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	String temp = equation.getText();
			    	equation.setText(temp + "1"); 
			    }
		 });
		 b2.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	String temp = equation.getText();
			    	equation.setText(temp + "2"); 
			    }
		 });
		 b3.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	String temp = equation.getText();
			    	equation.setText(temp + "3"); 
			    }
		 });
		 b4.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	String temp = equation.getText();
			    	equation.setText(temp + "4"); 
			    }
		 });
		 b5.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	String temp = equation.getText();
			    	equation.setText(temp + "5"); 
			    }
		 });
		 b6.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	String temp = equation.getText();
			    	equation.setText(temp + "6"); 
			    }
		 });
		 b7.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	String temp = equation.getText();
			    	equation.setText(temp + "7"); 
			    }
		 });
		 b8.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	String temp = equation.getText();
			    	equation.setText(temp + "8"); 
			    }
		 });
		 b9.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	String temp = equation.getText();
			    	equation.setText(temp + "9"); 
			    }
		 });
		 b0.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	String temp = equation.getText();
			    	equation.setText(temp + "0"); 
			    }
		 });
		 bp.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 	plus = true;
				 	String temp = equation.getText();
				 	equation.setText(temp + "+"); 
			    }
		 });
		 bs.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 	subtract = true;
				 	String temp = equation.getText();
				 	equation.setText(temp + "-"); 
			    }
		 });
		 bm.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 	multiply = true;
				 	String temp = equation.getText();
			    	equation.setText(temp + "*"); 
			    }
		 });
		 bd.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 	divide = true;
				 	String temp = equation.getText();
				 	equation.setText(temp + "/"); 
			    }
		 });
		 bc.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	equation.setText("");
			    	answer.setText("");
			    	plus = false;
			    	subtract = false;
			    	divide = false;
			    	multiply = false;
			    	
			    }
		 });
		 
		 be.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 //change how equals works depending on operator
				 String nums[] = new String[2];
				 if (plus == true) {
					 nums = equation.getText().split("\\+");
					 double a = Double.parseDouble(nums[0]);
					 double b = Double.parseDouble(nums[1]);
					 double c = (a+b);
					 String ans = Double.toString(c);
					 answer.setText(ans);
					 
				 }else if (subtract == true) {
					 nums = equation.getText().split("-");
					 double a = Double.parseDouble(nums[0]);
					 double b = Double.parseDouble(nums[1]);
					 double c = (a-b);
					 String ans = String.valueOf(c);
					 answer.setText(ans);
					 
				 }else if (multiply == true) {
					 nums = equation.getText().split("\\*");
					 double a = Double.parseDouble(nums[0]);
					 double b = Double.parseDouble(nums[1]);
					 double c = (a * b);
					 String ans = String.valueOf(c);
					 answer.setText(ans);
					 
				 }else if (divide == true){
					 nums = equation.getText().split("/");
					 double a = Double.parseDouble(nums[0]);
					 double b = Double.parseDouble(nums[1]);
					 double c = (a / b);
					 String ans = String.valueOf(c);
					 answer.setText(ans);
				 }
			  }
		 });
	 }
}
	       
	 
	

